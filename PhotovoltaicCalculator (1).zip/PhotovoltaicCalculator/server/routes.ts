import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertCalculationSchema } from "@shared/schema";

export async function registerRoutes(app: Express) {
  app.post("/api/calculate", async (req, res) => {
    try {
      const data = insertCalculationSchema.parse(req.body);
      const result = await storage.saveCalculation(data);
      res.json(result);
    } catch (error) {
      res.status(400).json({ error: "Invalid calculation data" });
    }
  });

  app.get("/api/calculation/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const calculation = await storage.getCalculation(id);
    if (!calculation) {
      res.status(404).json({ error: "Calculation not found" });
      return;
    }
    res.json(calculation);
  });

  return createServer(app);
}

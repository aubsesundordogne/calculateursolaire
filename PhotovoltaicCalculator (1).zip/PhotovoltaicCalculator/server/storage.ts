import { calculations, type Calculation, type InsertCalculation } from "@shared/schema";

export interface IStorage {
  saveCalculation(calc: InsertCalculation): Promise<Calculation>;
  getCalculation(id: number): Promise<Calculation | undefined>;
}

export class MemStorage implements IStorage {
  private calculations: Map<number, Calculation>;
  private currentId: number;

  constructor() {
    this.calculations = new Map();
    this.currentId = 1;
  }

  async saveCalculation(calc: InsertCalculation): Promise<Calculation> {
    const id = this.currentId++;
    const calculation: Calculation = { ...calc, id };
    this.calculations.set(id, calculation);
    return calculation;
  }

  async getCalculation(id: number): Promise<Calculation | undefined> {
    return this.calculations.get(id);
  }
}

export const storage = new MemStorage();

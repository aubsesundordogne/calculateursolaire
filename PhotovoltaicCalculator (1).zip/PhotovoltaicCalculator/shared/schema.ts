import { pgTable, text, serial, integer, decimal } from "drizzle-orm/pg-core";
import { z } from "zod";

export const calculations = pgTable("calculations", {
  id: serial("id").primaryKey(),
  houseType: text("house_type").notNull(),
  roofType: text("roof_type").notNull(),
  roofAngle: integer("roof_angle").notNull(),
  roofOrientation: text("roof_orientation").notNull(),
  roofArea: decimal("roof_area").notNull(),
  shadingLevel: text("shading_level").notNull(),
  energyUsage: decimal("energy_usage").notNull(),
  recommendedPower: decimal("recommended_power").notNull(),
  estimatedSavings: decimal("estimated_savings").notNull(),
  estimatedProduction: decimal("estimated_production").notNull()
});

// Create a custom insert schema that handles number inputs correctly
export const insertCalculationSchema = z.object({
  houseType: z.string(),
  roofType: z.string(),
  roofAngle: z.number(),
  roofOrientation: z.string(),
  roofArea: z.number(),
  shadingLevel: z.string(),
  energyUsage: z.number(),
  recommendedPower: z.number(),
  estimatedSavings: z.number(),
  estimatedProduction: z.number()
});

export type InsertCalculation = z.infer<typeof insertCalculationSchema>;
export type Calculation = typeof calculations.$inferSelect;
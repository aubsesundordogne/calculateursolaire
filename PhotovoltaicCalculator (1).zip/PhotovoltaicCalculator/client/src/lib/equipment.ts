// Définition des équipements électriques et leur consommation moyenne annuelle
export const ELECTRICAL_EQUIPMENT = {
  vehicules: [
    {
      id: "voiture-electrique",
      label: "Voiture électrique",
      description: "Recharge à domicile",
      consumption: 2500, // kWh/an en moyenne
      icon: "🚗"
    },
    {
      id: "velo-electrique",
      label: "Vélo électrique",
      description: "Recharge régulière",
      consumption: 100,
      icon: "🚲"
    }
  ],
  chauffage: [
    {
      id: "chauffage-principal",
      label: "Chauffage électrique principal",
      description: "Chauffage principal du logement",
      consumption: 4000,
      icon: "🌡️"
    },
    {
      id: "pompe-chaleur",
      label: "Pompe à chaleur",
      description: "PAC air-air ou air-eau",
      consumption: 3000,
      icon: "♨️"
    },
    {
      id: "chauffage-appoint",
      label: "Chauffage d'appoint",
      description: "Radiateur électrique mobile",
      consumption: 800,
      icon: "🔥"
    }
  ],
  eau: [
    {
      id: "chauffe-eau",
      label: "Chauffe-eau électrique",
      description: "Production d'eau chaude",
      consumption: 2500,
      icon: "🚿"
    }
  ],
  equipements: [
    {
      id: "electromenager",
      label: "Électroménager standard",
      description: "Frigo, lave-linge, lave-vaisselle, etc.",
      consumption: 800,
      icon: "🏠"
    },
    {
      id: "cuisine",
      label: "Cuisine électrique",
      description: "Plaques, four, micro-ondes",
      consumption: 600,
      icon: "👨‍🍳"
    },
    {
      id: "multimedia",
      label: "Multimédia",
      description: "TV, ordinateurs, consoles",
      consumption: 500,
      icon: "📺"
    },
    {
      id: "eclairage",
      label: "Éclairage",
      description: "Tout l'éclairage du logement",
      consumption: 400,
      icon: "💡"
    }
  ]
};

// Calculer la consommation totale des équipements sélectionnés
export function calculateTotalConsumption(selectedEquipment: string[]): number {
  let total = 0;
  
  // Parcourir toutes les catégories
  Object.values(ELECTRICAL_EQUIPMENT).forEach(category => {
    category.forEach(equipment => {
      if (selectedEquipment.includes(equipment.id)) {
        total += equipment.consumption;
      }
    });
  });

  return total;
}

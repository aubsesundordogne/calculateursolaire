// Calcule la puissance recommandée des panneaux solaires en kWc
export function calculateRecommendedPower(
  energyUsage: number,
  roofAngle: number,
  roofOrientation: string,
  roofArea: number,
  shadingLevel: string
): number {
  // 1. Calcul de la consommation quotidienne en kWh
  const dailyConsumption = energyUsage / 365;

  // 2. Ensoleillement moyen en France (en kWh/m²/jour)
  // Valeurs plus conservatrices basées sur les moyennes EDF
  const solarIrradianceMap: Record<string, number> = {
    "sud": 3.8, // Optimal
    "sud-est": 3.6,
    "sud-ouest": 3.6,
    "est": 3.0,
    "ouest": 3.0,
    "nord-est": 2.4,
    "nord-ouest": 2.4,
    "nord": 2.0
  };

  const baseIrradiance = solarIrradianceMap[roofOrientation] || 3.0;

  // 3. Ajustement pour l'angle du toit
  // Maximum d'efficacité entre 30° et 35°
  const angleEfficiency = 1 - Math.abs(32.5 - roofAngle) / 90;

  // 4. Facteur d'ombrage (ajusté selon les recommandations EDF)
  const shadingFactorMap: Record<string, number> = {
    "aucun": 1.0,
    "leger": 0.85,
    "modere": 0.7,
    "important": 0.5
  };
  const shadingFactor = shadingFactorMap[shadingLevel] || 0.7;

  // 5. Calcul de la puissance nécessaire en kWc
  // On considère que 20-30% de la consommation peut être couverte
  const targetCoverage = 0.25; // 25% de la consommation
  let recommendedPower = (dailyConsumption * targetCoverage) / (baseIrradiance * angleEfficiency * shadingFactor);

  // 6. Ajout d'un facteur de perte système de 20%
  recommendedPower = recommendedPower * 1.2;

  // 7. Vérification de la faisabilité avec la surface disponible
  // En moyenne, 1 kWc nécessite environ 5-6m² de surface
  const maxPowerFromArea = roofArea / 6;

  if (recommendedPower > maxPowerFromArea) {
    console.log(`Surface disponible (${roofArea}m²) insuffisante pour ${recommendedPower.toFixed(2)}kWc.`);
    console.log(`La puissance maximale possible avec cette surface est de ${maxPowerFromArea.toFixed(2)}kWc.`);
    return Number(maxPowerFromArea.toFixed(2));
  }

  return Number(recommendedPower.toFixed(2));
}

// Calcule la production annuelle estimée en kWh
export function calculateEstimatedProduction(
  recommendedPower: number,
  roofOrientation: string,
  shadingLevel: string
): number {
  // Production annuelle moyenne en France: environ 1000 kWh/kWc
  // Valeur plus conservative que précédemment
  const baseProduction = recommendedPower * 1000;

  // Ajustement selon l'orientation (facteurs ajustés selon EDF)
  const orientationFactorMap: Record<string, number> = {
    "sud": 1.0,
    "sud-est": 0.9,
    "sud-ouest": 0.9,
    "est": 0.8,
    "ouest": 0.8,
    "nord-est": 0.7,
    "nord-ouest": 0.7,
    "nord": 0.6,
  };

  const shadingFactorMap: Record<string, number> = {
    "aucun": 1.0,
    "leger": 0.85,
    "modere": 0.7,
    "important": 0.5
  };

  const orientationFactor = orientationFactorMap[roofOrientation] || 0.8;
  const shadingFactor = shadingFactorMap[shadingLevel] || 0.7;

  return Number((baseProduction * orientationFactor * shadingFactor).toFixed(2));
}

// Calcule les économies annuelles estimées en euros
export function calculateEstimatedSavings(
  estimatedProduction: number,
  currentPrice: number = 0.1740 // Prix moyen du kWh en France en 2024
): number {
  return Number((estimatedProduction * currentPrice).toFixed(2));
}
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertCalculationSchema } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { calculateRecommendedPower, calculateEstimatedSavings, calculateEstimatedProduction } from "@/lib/calculations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Home, Sun, Ruler, Battery, ArrowRight, House, Hotel, Building2, Factory } from "lucide-react";
import { motion } from "framer-motion";
import { ELECTRICAL_EQUIPMENT, calculateTotalConsumption } from "@/lib/equipment";

const STEPS = [
  {
    title: "Équipements électriques",
    description: "Sélectionnez vos équipements consommateurs d'électricité"
  },
  {
    title: "Consommation annuelle",
    description: "Cette information est la base du dimensionnement de votre installation"
  },
  {
    title: "Type de bâtiment",
    description: "Pour adapter les recommandations à votre situation"
  },
  {
    title: "Type de toiture",
    description: "La configuration de votre toit influence l'installation"
  },
  {
    title: "Angle de la toiture",
    description: "L'inclinaison optimale est entre 30° et 35°"
  },
  {
    title: "Orientation",
    description: "L'orientation Sud est optimale pour la production"
  },
  {
    title: "Surface disponible",
    description: "Pour vérifier la faisabilité de l'installation"
  },
  {
    title: "Ombrage",
    description: "L'ombrage peut impacter significativement la production"
  }
];

const HOUSE_TYPES = [
  { value: "maison", label: "Maison individuelle", icon: House },
  { value: "appartement", label: "Appartement", icon: Building2 },
  { value: "immeuble", label: "Immeuble", icon: Hotel },
  { value: "industriel", label: "Bâtiment industriel", icon: Factory }
];

const ROOF_TYPES = [
  { value: "plat", label: "Toit plat", description: "Surface horizontale idéale pour les panneaux" },
  { value: "incline", label: "Toit incliné", description: "Meilleure exposition selon l'orientation" },
  { value: "complexe", label: "Toit complexe", description: "Plusieurs faces et angles différents" }
];

const ROOF_ORIENTATIONS = [
  { value: "sud", label: "Sud (Optimal)", icon: "⭐", description: "Production optimale" },
  { value: "sud-est", label: "Sud-Est", icon: "↗️", description: "Très bonne production" },
  { value: "sud-ouest", label: "Sud-Ouest", icon: "↘️", description: "Très bonne production" },
  { value: "est", label: "Est", icon: "➡️", description: "Production moyenne" },
  { value: "ouest", label: "Ouest", icon: "⬅️", description: "Production moyenne" },
  { value: "nord-est", label: "Nord-Est", icon: "↖️", description: "Production limitée" },
  { value: "nord-ouest", label: "Nord-Ouest", icon: "↙️", description: "Production limitée" },
  { value: "nord", label: "Nord", icon: "⬆️", description: "Production faible, non recommandé" }
];

const SHADING_LEVELS = [
  {
    value: "aucun",
    label: "Aucun ombrage",
    description: "Exposition totale au soleil toute la journée"
  },
  {
    value: "leger",
    label: "Ombrage léger",
    description: "Quelques ombres en début/fin de journée"
  },
  {
    value: "modere",
    label: "Ombrage modéré",
    description: "Zones d'ombre pendant certaines heures"
  },
  {
    value: "important",
    label: "Ombrage important",
    description: "Zones d'ombre significatives"
  }
];

export default function SolarCalculator() {
  const [step, setStep] = useState(1);
  const [results, setResults] = useState<any>(null);
  const [selectedEquipment, setSelectedEquipment] = useState<string[]>([]);
  const { toast } = useToast();

  const form = useForm({
    resolver: zodResolver(insertCalculationSchema),
    defaultValues: {
      houseType: "maison",
      roofType: "",
      roofAngle: 30,
      roofOrientation: "",
      roofArea: 0,
      shadingLevel: "",
      energyUsage: 0,
      recommendedPower: 0,
      estimatedSavings: 0,
      estimatedProduction: 0
    }
  });

  const calculate = useMutation({
    mutationFn: async (data: any) => {
      const recommendedPower = calculateRecommendedPower(
        data.energyUsage,
        data.roofAngle,
        data.roofOrientation,
        data.roofArea,
        data.shadingLevel
      );

      const estimatedProduction = calculateEstimatedProduction(
        recommendedPower,
        data.roofOrientation,
        data.shadingLevel
      );

      const estimatedSavings = calculateEstimatedSavings(estimatedProduction);

      const fullData = {
        ...data,
        recommendedPower,
        estimatedProduction,
        estimatedSavings
      };

      const response = await apiRequest("POST", "/api/calculate", fullData);
      return response.json();
    },
    onSuccess: (data) => {
      setResults(data);
      toast({
        title: "Calcul terminé",
        description: "Votre estimation d'installation solaire est prête !"
      });
    }
  });

  const onSubmit = form.handleSubmit((data) => {
    if (step < 7) {
      setStep(step + 1);
    } else {
      calculate.mutate(data);
    }
  });

  const goBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-green-50 p-4 md:p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="max-w-2xl mx-auto shadow-lg">
          <CardHeader className="space-y-1">
            <CardTitle className="flex items-center gap-3 text-2xl">
              <Sun className="w-8 h-8 text-yellow-500" />
              Calculateur Solaire
            </CardTitle>
            <p className="text-muted-foreground">
              Estimez votre installation photovoltaïque en quelques étapes
            </p>
          </CardHeader>

          <CardContent>
            <Form {...form}>
              <form onSubmit={onSubmit} className="space-y-6">
                {/* Progress Steps */}
                <div className="space-y-2">
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">
                      Étape {step} sur {STEPS.length}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      {STEPS[step - 1].title}
                    </span>
                  </div>
                  <div className="flex gap-1">
                    {STEPS.map((s, i) => (
                      <div
                        key={i}
                        className={`h-2 flex-1 rounded-full transition-colors ${
                          step > i ? "bg-primary" : "bg-gray-200"
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {STEPS[step - 1].description}
                  </p>
                </div>

                {/* Nouvelle étape - Sélection des équipements */}
                {step === 1 && (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="space-y-6"
                  >
                    <div className="space-y-4">
                      {Object.entries(ELECTRICAL_EQUIPMENT).map(([category, items]) => (
                        <div key={category} className="space-y-3">
                          <h3 className="text-lg font-semibold capitalize">
                            {category.replace("-", " ")}
                          </h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {items.map((equipment) => (
                              <div
                                key={equipment.id}
                                className={`p-4 rounded-lg border-2 cursor-pointer hover:border-primary transition-colors ${
                                  selectedEquipment.includes(equipment.id)
                                    ? "border-primary bg-primary/10"
                                    : "border-gray-200"
                                }`}
                                onClick={() => {
                                  setSelectedEquipment((prev) =>
                                    prev.includes(equipment.id)
                                      ? prev.filter((id) => id !== equipment.id)
                                      : [...prev, equipment.id]
                                  );
                                  const totalConsumption = calculateTotalConsumption([...selectedEquipment, equipment.id]);
                                  form.setValue("energyUsage", totalConsumption);
                                }}
                              >
                                <div className="flex items-center gap-3">
                                  <span className="text-2xl">{equipment.icon}</span>
                                  <div>
                                    <div className="font-medium">{equipment.label}</div>
                                    <div className="text-sm text-muted-foreground">
                                      {equipment.description}
                                    </div>
                                    <div className="text-sm text-primary">
                                      ~{equipment.consumption} kWh/an
                                    </div>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-4 p-4 bg-muted rounded-lg">
                      <div className="font-medium">
                        Consommation totale estimée :
                        {calculateTotalConsumption(selectedEquipment)} kWh/an
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        Cette estimation sera utilisée comme base pour le dimensionnement.
                        Vous pourrez l'ajuster à l'étape suivante si nécessaire.
                      </p>
                    </div>
                  </motion.div>
                )}

                {/* Step 1 - Consommation */}
                {step === 2 && (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="space-y-4"
                  >
                    <FormField
                      control={form.control}
                      name="energyUsage"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Consommation annuelle (kWh/an)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              placeholder="Ex: 3500"
                              {...field}
                              onChange={(e) => field.onChange(Number(e.target.value))}
                            />
                          </FormControl>
                          <div className="text-sm text-muted-foreground">
                            Estimation basée sur vos équipements : {calculateTotalConsumption(selectedEquipment)} kWh/an
                            <br />
                            Vous pouvez ajuster cette valeur si elle ne correspond pas à votre consommation réelle
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </motion.div>
                )}

                {/* Step 2 - Type de bâtiment */}
                {step === 3 && (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="space-y-4"
                  >
                    <h2 className="text-lg font-semibold">Type de bâtiment</h2>
                    <FormField
                      control={form.control}
                      name="houseType"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <div className="grid grid-cols-2 gap-4">
                              {HOUSE_TYPES.map((type) => {
                                const Icon = type.icon;
                                return (
                                  <button
                                    key={type.value}
                                    type="button"
                                    className={`p-4 rounded-lg border-2 flex flex-col items-center gap-2 hover:border-primary transition-colors ${
                                      field.value === type.value
                                        ? "border-primary bg-primary/10"
                                        : "border-gray-200"
                                    }`}
                                    onClick={() => field.onChange(type.value)}
                                  >
                                    <Icon className="w-8 h-8" />
                                    <span>{type.label}</span>
                                  </button>
                                );
                              })}
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </motion.div>
                )}

                {/* Step 3 - Type de toiture */}
                {step === 4 && (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="space-y-4"
                  >
                    <h2 className="text-lg font-semibold">Type de toiture</h2>
                    <FormField
                      control={form.control}
                      name="roofType"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <div className="space-y-3">
                              {ROOF_TYPES.map((type) => (
                                <div
                                  key={type.value}
                                  className={`p-4 rounded-lg border-2 hover:border-primary transition-colors ${
                                    field.value === type.value
                                      ? "border-primary bg-primary/10"
                                      : "border-gray-200"
                                  }`}
                                  onClick={() => field.onChange(type.value)}
                                >
                                  <div className="font-medium">{type.label}</div>
                                  <div className="text-sm text-muted-foreground">
                                    {type.description}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </motion.div>
                )}

                {/* Step 4 - Angle de la toiture */}
                {step === 5 && (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="space-y-4"
                  >
                    <h2 className="text-lg font-semibold">Angle de la toiture</h2>
                    <FormField
                      control={form.control}
                      name="roofAngle"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <div className="space-y-4">
                              <Slider
                                min={0}
                                max={90}
                                step={1}
                                value={[field.value]}
                                onValueChange={(vals) => field.onChange(vals[0])}
                                className="py-4"
                              />
                              <div className="text-center text-lg">
                                {field.value}°
                              </div>
                              <div className="flex justify-center">
                                <Ruler className="w-6 h-6 text-muted-foreground" />
                              </div>
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </motion.div>
                )}

                {/* Step 5 - Orientation du toit */}
                {step === 6 && (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="space-y-4"
                  >
                    <h2 className="text-lg font-semibold">Orientation du toit</h2>
                    <FormField
                      control={form.control}
                      name="roofOrientation"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <div className="grid grid-cols-2 gap-3">
                              {ROOF_ORIENTATIONS.map((orientation) => (
                                <button
                                  key={orientation.value}
                                  type="button"
                                  className={`p-4 rounded-lg border-2 flex items-center gap-3 hover:border-primary transition-colors ${
                                    field.value === orientation.value
                                      ? "border-primary bg-primary/10"
                                      : "border-gray-200"
                                  }`}
                                  onClick={() => field.onChange(orientation.value)}
                                >
                                  <span className="text-2xl">{orientation.icon}</span>
                                  <span>{orientation.label}</span>
                                  <span className="text-sm text-muted-foreground">
                                    {orientation.description}
                                  </span>
                                </button>
                              ))}
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </motion.div>
                )}

                {/* Step 6 - Surface disponible */}
                {step === 7 && (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="space-y-4"
                  >
                    <h2 className="text-lg font-semibold">Surface disponible</h2>
                    <div className="text-sm text-muted-foreground mb-4">
                      Cette information nous permet de vérifier la faisabilité de l'installation.
                      En moyenne, 1 kWc nécessite environ 6m² de surface de toit.
                    </div>
                    <FormField
                      control={form.control}
                      name="roofArea"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Surface disponible en m²</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              placeholder="Ex: 25"
                              {...field}
                              onChange={(e) => field.onChange(Number(e.target.value))}
                            />
                          </FormControl>
                          <div className="text-sm text-muted-foreground">
                            Surface approximative disponible sur votre toit pour les panneaux
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </motion.div>
                )}

                {/* Step 7 - Niveau d'ombrage */}
                {step === 8 && (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="space-y-4"
                  >
                    <h2 className="text-lg font-semibold">Niveau d'ombrage</h2>
                    <FormField
                      control={form.control}
                      name="shadingLevel"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <div className="space-y-3">
                              {SHADING_LEVELS.map((level) => (
                                <div
                                  key={level.value}
                                  className={`p-4 rounded-lg border-2 hover:border-primary transition-colors ${
                                    field.value === level.value
                                      ? "border-primary bg-primary/10"
                                      : "border-gray-200"
                                  }`}
                                  onClick={() => field.onChange(level.value)}
                                >
                                  <div className="font-medium">{level.label}</div>
                                  <div className="text-sm text-muted-foreground">
                                    {level.description}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </motion.div>
                )}

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="flex gap-3"
                >
                  {step > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      className="flex-1"
                      onClick={goBack}
                    >
                      Précédent
                    </Button>
                  )}
                  <Button
                    type="submit"
                    className="flex-1"
                    disabled={calculate.isPending}
                  >
                    {step < 8 ? (
                      <>
                        Suivant
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </>
                    ) : (
                      "Calculer"
                    )}
                  </Button>
                </motion.div>
              </form>
            </Form>

            {results && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-8 space-y-6"
              >
                <h2 className="text-xl font-semibold text-center">
                  Résultats de l'estimation
                </h2>
                <div className="grid gap-4">
                  <div className="p-6 bg-green-50 rounded-lg">
                    <h3 className="font-semibold text-green-700 mb-2">
                      Puissance Recommandée
                    </h3>
                    <p className="text-3xl font-bold text-green-600">
                      {results.recommendedPower} kWc
                    </p>
                    <p className="text-sm text-green-600 mt-2">
                      Cette puissance est calculée en fonction de votre consommation et des conditions d'installation
                    </p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-6 bg-blue-50 rounded-lg">
                      <h3 className="font-semibold text-blue-700 mb-2">
                        Production Annuelle Estimée
                      </h3>
                      <p className="text-3xl font-bold text-blue-600">
                        {results.estimatedProduction} kWh
                      </p>
                      <p className="text-sm text-blue-600 mt-2">
                        Basée sur l'ensoleillement moyen de votre région
                      </p>
                    </div>
                    <div className="p-6 bg-amber-50 rounded-lg">
                      <h3 className="font-semibold text-amber-700 mb-2">
                        Économies Annuelles Estimées
                      </h3>
                      <p className="text-3xl font-bold text-amber-600">
                        {results.estimatedSavings}€
                      </p>
                      <p className="text-sm text-amber-600 mt-2">
                        Calculées avec le tarif actuel de l'électricité
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}